﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prueba_25_febrero
{
    internal class Program
    {
        static void Main(string[] args)
        {
           //variables para el ejercicio 9
            double notas = 0;
            double suma = 0;
            double n = 0;
           //variables para el ejercicio 22
            double interes, capital;

           //variable para ejercicio 44
            int edad;

            //variable para ejercicio 50
            int n2;

            //varibles para validar en caso de introducir un caracter o 0
            int seguir = 1, opcion = 0;
            int numero;
            string entrada;
            bool isNumber;


            //se seguira ejecutando el programa mientras la condicion del while se cumpla
            while (seguir == 1)
            {

                Console.WriteLine("***************PRUEBA 25 DE FEBRERO**********************");
                Console.WriteLine("1- Ejercicio numero 9");
                Console.WriteLine("2- Ejercicio numero 22");
                Console.WriteLine("3- Ejercicio numero 44");
                Console.WriteLine("4- Ejercicio numero 50");
                Console.WriteLine("5- Salir");
                Console.WriteLine("Eliga una opcion del 1-5");

                do
                {
                    entrada = Console.ReadLine();
                    isNumber = int.TryParse(entrada, out numero);

                    if (isNumber)

                    {
                        opcion = numero;
                    }
                    else
                    {
                        Console.WriteLine("***************PRUEBA 25 DE FEBRERO**********************");
                        Console.WriteLine("1- Ejercicio numero 9");
                        Console.WriteLine("2- Ejercicio numero 22");
                        Console.WriteLine("3- Ejercicio numero 44");
                        Console.WriteLine("4- Ejercicio numero 50");
                        Console.WriteLine("5- Salir");
                        Console.WriteLine("Eliga una opcion del 1-5");
                    }
                } while (!isNumber);


                switch (opcion)
                {

                    case 1:

                        Console.WriteLine("********** PROGRAMA PARA CALCULAR EL PROMEDIO **********");
                        Console.WriteLine("Ingrese el numero de notas a promediar: ");
                        n = double.Parse(Console.ReadLine());

                        for (int i = 1; i <= n; i++)
                        {
                            Console.WriteLine("Digite la nota numero " + (i) + ": ");
                            notas = double.Parse(Console.ReadLine());
                            suma = suma + notas;

                        }

                        Console.WriteLine("El promedio es: " + (suma / n) +"\n");
                        Console.WriteLine("Escriba 1 para volver a ejecutar");
                        Console.WriteLine("Escriba 0 para salir ");
                          seguir = int.Parse(Console.ReadLine());


                        break;
                    case 2:
                        Console.WriteLine("*********** Calcular interes *************");
                        Console.WriteLine("Ingrese el monto del capital");
                        capital = double.Parse(Console.ReadLine());

                        if (capital >= 10000)
                        {
                            Console.WriteLine("El interes es de 7%\n");
                            interes = capital * 0.07;

                            Console.WriteLine("El interes es de:" + interes + "\n");
                            Console.WriteLine("Escriba 1 para volver a ejecutar");
                            Console.WriteLine("Escriba 0 para salir ");
                              seguir = int.Parse(Console.ReadLine());
                        }
                        else
                        {
                            Console.WriteLine("El interes es de 6%\n");
                            interes = capital * 0.06;

                            Console.WriteLine("El interes es de:" + interes + "\n");
                            Console.WriteLine("Escriba 1 para volver a ejecutar");
                            Console.WriteLine("Escriba 0 para salir ");
                             seguir = int.Parse(Console.ReadLine());
                        }

                            break;
                    case 3:

                        Console.WriteLine(" *******EDAD*******");

                        Console.WriteLine(" ¿Cual es tu edad? ");
                        edad = int.Parse(Console.ReadLine());

                            if (edad <= 13)
                            {

                                Console.WriteLine("Eres un niño" + "\n");
                                Console.WriteLine("Escriba 1 para volver a ejecutar");
                                Console.WriteLine("Escriba 0 para salir ");
                                  seguir = int.Parse(Console.ReadLine());

                            }
                            if (edad >= 14 && edad <= 25)
                            {

                                Console.WriteLine(" Eres joven" + "\n");
                                Console.WriteLine("Escriba 1 para volver a ejecutar");
                                Console.WriteLine("Escriba 0 para salir ");
                                  seguir = int.Parse(Console.ReadLine());
                            }
                            if (edad >= 26)
                            {
                                Console.WriteLine("Eres un adulto" + "\n");
                                Console.WriteLine("Escriba 1 para volver a ejecutar");
                                Console.WriteLine("Escriba 0 para salir ");
                                  seguir = int.Parse(Console.ReadLine());

                            }

                            break;
                    case 4:
                       
                        Console.WriteLine("*******Programa para averiguar los divisores de un numero entero*********");
                        Console.WriteLine("Escriba el numero del cual quiere saber sus divisores\n");
                         n2 = int.Parse(Console.ReadLine());

                        for (int i = 1; i <= n2; i++)
                        {
                            if (n2 % i == 0)
                            {
                                Console.WriteLine("Los divisores son: " + i);

                            }
                           
                        }

                        Console.WriteLine("\n" + "Escriba 1 para volver a ejecutar");
                        Console.WriteLine("Escriba 0 para salir ");
                          seguir = int.Parse(Console.ReadLine());

                        break;
                    case 5:
                        
                        Console.WriteLine("Escriba 1 para volver a ejecutar");
                        Console.WriteLine("Escriba 0 para salir ");
                        seguir = int.Parse(Console.ReadLine());

                        break;

                    default:

                        Console.WriteLine("La opcion que eligio no existe\n");
                        Console.WriteLine("Escriba 1 para volver a ejecutar");
                        Console.WriteLine("Escriba 0 para salir ");
                        seguir = int.Parse(Console.ReadLine());

                        break;

                }
            }
        }
    }
}
